<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'qing', 'yu', 'piao', 'ji', 'ya', 'chao', 'qi', 'xi', 'ji', 'lu', 'lou', 'long', 'jin', 'guo', 'cong', 'lou',
  0x10 => 'zhi', 'gai', 'qiang', 'li', 'yan', 'cao', 'jiao', 'cong', 'chun', 'tuan', 'ou', 'teng', 'ye', 'xi', 'mi', 'tang',
  0x20 => 'mo', 'shang', 'han', 'lian', 'lan', 'wa', 'chi', 'gan', 'feng', 'xuan', 'yi', 'man', 'zi', 'mang', 'kang', 'luo',
  0x30 => 'peng', 'shu', 'zhang', 'zhang', 'zhuang', 'xu', 'huan', 'huo', 'jian', 'yan', 'shuang', 'liao', 'cui', 'ti', 'yang', 'jiang',
  0x40 => 'cong', 'ying', 'hong', 'xun', 'shu', 'guan', 'ying', 'xiao', 'zong', 'kun', 'xu', 'lian', 'zhi', 'wei', 'pi', 'yu',
  0x50 => 'jiao', 'po', 'dang', 'hui', 'jie', 'wu', 'pa', 'ji', 'pan', 'wei', 'su', 'qian', 'qian', 'xi', 'lu', 'xi',
  0x60 => 'xun', 'dun', 'huang', 'min', 'run', 'su', 'lao', 'zhen', 'cong', 'yi', 'zhe', 'wan', 'shan', 'tan', 'chao', 'xun',
  0x70 => 'kui', 'ye', 'shao', 'tu', 'zhu', 'sa', 'hei', 'bi', 'shan', 'chan', 'chan', 'shu', 'tong', 'pu', 'lin', 'wei',
  0x80 => 'se', 'se', 'cheng', 'jiong', 'cheng', 'hua', 'jiao', 'lao', 'che', 'gan', 'cun', 'hong', 'si', 'shu', 'peng', 'han',
  0x90 => 'yun', 'liu', 'hong', 'fu', 'hao', 'he', 'xian', 'jian', 'shan', 'xi', 'yu', 'lu', 'lan', 'ning', 'yu', 'lin',
  0xA0 => 'mian', 'zao', 'dang', 'huan', 'ze', 'xie', 'yu', 'li', 'shi', 'xue', 'ling', 'wan', 'zi', 'yong', 'hui', 'can',
  0xB0 => 'lian', 'dian', 'ye', 'ao', 'huan', 'zhen', 'chan', 'man', 'dan', 'dan', 'yi', 'sui', 'pi', 'ju', 'ta', 'qin',
  0xC0 => 'ji', 'zhuo', 'lian', 'nong', 'guo', 'jin', 'fen', 'se', 'ji', 'sui', 'hui', 'chu', 'ta', 'song', 'ding', 'se',
  0xD0 => 'zhu', 'lai', 'bin', 'lian', 'mi', 'shi', 'shu', 'mi', 'ning', 'ying', 'ying', 'meng', 'jin', 'qi', 'bi', 'ji',
  0xE0 => 'hao', 'ru', 'cui', 'wo', 'tao', 'yin', 'yin', 'dui', 'ci', 'huo', 'jing', 'lan', 'jun', 'ai', 'pu', 'zhuo',
  0xF0 => 'wei', 'bin', 'gu', 'qian', 'ying', 'bin', 'kuo', 'fei', 'cang', 'me', 'jian', 'wei', 'luo', 'zan', 'lu', 'li',
];
